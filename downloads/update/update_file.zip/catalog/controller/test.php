<?php 
	class TestController extends Controller {
        public function index()
        {
            echo phpinfo();
        }
    }
?>