<?php 
	define('BASE', $base);
	define('BASE_FOL', $base);
	define('BASE_CATALOG', $base.'catalog/');
	define('THEME','theme');
	define('BASE_ASSET', MURL.'assets/'.THEME.'/');
?>